import React, { Component } from "react";

// class MyNewComponent extends Component {
//   render() {
//     const { firstName, lastName, age, hairColor } = this.props;
//     return (
//       <div>
//         <div>
//           <h2>
//             {firstName} {lastName}
//           </h2>
//           <h3>{age}</h3>
//           <h3>{hairColor}</h3>
//           <button>Birthday Button for {firstName}</button>
//         </div>
//       </div>
//     );
//   }
// }

class MyNewComponent extends Component {
  constructor(props) {
    super(props);
    this.state = {
      current_age: this.props.age,
    };
  }

  increaseAge = () => {
    this.setState({
      current_age: this.state.current_age + 1,
    });
  };

  render() {
    return (
      <div>
        <div>
          <h2>
            {this.props.firstName} {this.props.lastName}
          </h2>
          <h3>{this.state.current_age}</h3>
          <h3>{this.props.hairColor}</h3>
          <button onClick={this.increaseAge}>
            Birthday Button for {this.props.firstName}
          </button>
        </div>
      </div>
    );
  }
}

export default MyNewComponent;
